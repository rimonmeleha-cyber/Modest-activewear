This is a single-file React landing page component (TypeScript/TSX compatible) ready to use in a React app.
Files:
- modest_activewear_landing.jsx  (main component)

Notes:
- Uses TailwindCSS + shadcn/ui + framer-motion + lucide-react. Install and configure these in your project.
- To preview quickly: create a Next.js app, add Tailwind, paste this file to /components and import into a page.
- I did not host the site. You can deploy this code to Vercel/Netlify for a live link.
